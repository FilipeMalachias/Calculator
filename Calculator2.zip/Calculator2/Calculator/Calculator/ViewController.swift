//
//  ViewController.swift
//  Calculator
//
//  Created by Filipe Malachias Resende on 2019-08-20.
//  Copyright © 2019 Malachias. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var numberLabel: UILabel!
    @IBOutlet var zero: UIButton!
    @IBOutlet var one: UIButton!
    @IBOutlet var two: UIButton!
    @IBOutlet var three: UIButton!
    @IBOutlet var four: UIButton!
    @IBOutlet var five: UIButton!
    @IBOutlet var six: UIButton!
    @IBOutlet var seven: UIButton!
    @IBOutlet var eight: UIButton!
    @IBOutlet var nine: UIButton!
    @IBOutlet var comma: UIButton!
    @IBOutlet var equal: UIButton!
    @IBOutlet var plus: UIButton!
    @IBOutlet var minus: UIButton!
    @IBOutlet var times: UIButton!
    @IBOutlet var division: UIButton!
    @IBOutlet var percentage: UIButton!
    @IBOutlet var inverterSignal: UIButton!
    @IBOutlet var clear: UIButton!
    
    var previusNumber:Double = 0
    var whatToDo = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func clear(_ sender: UIButton)
    {
        numberLabel.text = "0"
        zero.isEnabled = true
        one.isEnabled = true
        two.isEnabled = true
        three.isEnabled = true
        four.isEnabled = true
        five.isEnabled = true
        six.isEnabled = true
        seven.isEnabled = true
        eight.isEnabled = true
        nine.isEnabled = true
        comma.isEnabled = true
    }
    
    @IBAction func inverterSignal(_ sender: UIButton)
    {
        var textLabel = numberLabel.text!
        if (textLabel[textLabel.startIndex] == "-")
        {
            textLabel.remove(at: textLabel.startIndex)
            numberLabel.text = textLabel
        } else
        {
            textLabel.insert("-", at: textLabel.startIndex)
            numberLabel.text = textLabel
        }
    }
    
    @IBAction func comma(_ sender: UIButton)
    {
//        numberLabel.text = numberLabel.text! + String(".")
        comma.isEnabled = false
        if (numberLabel.text! == "0"
            || numberLabel.text! == "+"
            || numberLabel.text! == "-"
            || numberLabel.text! == "×"
            || numberLabel.text! == "÷"
            || numberLabel.text! == "%")
        {
            numberLabel.text = String("0.")
        } else
        {
            numberLabel.text = numberLabel.text! + String(".")
        }
    }
    
    
    @IBAction func plus(_ sender: UIButton)
    {
        if (numberLabel.text! == "0")
        {
            numberLabel.text = "0"
        } else
        {
            previusNumber = Double(numberLabel.text!)!
            numberLabel.text = "+"
            whatToDo = "+"
            zero.isEnabled = true
            one.isEnabled = true
            two.isEnabled = true
            three.isEnabled = true
            four.isEnabled = true
            five.isEnabled = true
            six.isEnabled = true
            seven.isEnabled = true
            eight.isEnabled = true
            nine.isEnabled = true
            comma.isEnabled = true
        }
    }
    
    
    @IBAction func minus(_ sender: UIButton)
    {
        if (numberLabel.text! == "0")
        {
            var textLabel2 = numberLabel.text!
            textLabel2.insert("-", at: textLabel2.startIndex)
            numberLabel.text = textLabel2
        } else
        {
            previusNumber = Double(numberLabel.text!)!
            numberLabel.text = "-"
            whatToDo = "-"
            zero.isEnabled = true
            one.isEnabled = true
            two.isEnabled = true
            three.isEnabled = true
            four.isEnabled = true
            five.isEnabled = true
            six.isEnabled = true
            seven.isEnabled = true
            eight.isEnabled = true
            nine.isEnabled = true
            comma.isEnabled = true
        }
    }
    
    @IBAction func times(_ sender: UIButton)
    {
        if (numberLabel.text! == "0")
        {
            numberLabel.text = "0"
        } else
        {
            previusNumber = Double(numberLabel.text!)!
            numberLabel.text = "×"
            whatToDo = "×"
            zero.isEnabled = true
            one.isEnabled = true
            two.isEnabled = true
            three.isEnabled = true
            four.isEnabled = true
            five.isEnabled = true
            six.isEnabled = true
            seven.isEnabled = true
            eight.isEnabled = true
            nine.isEnabled = true
            comma.isEnabled = true
        }
    }
    
    @IBAction func divide(_ sender: UIButton)
    {
        if (numberLabel.text! == "0")
        {
            numberLabel.text = "0"
        } else
        {
            previusNumber = Double(numberLabel.text!)!
            numberLabel.text = "÷"
            whatToDo = "÷"
            zero.isEnabled = true
            one.isEnabled = true
            two.isEnabled = true
            three.isEnabled = true
            four.isEnabled = true
            five.isEnabled = true
            six.isEnabled = true
            seven.isEnabled = true
            eight.isEnabled = true
            nine.isEnabled = true
            comma.isEnabled = true
        }
    }
    
    @IBAction func percentage(_ sender: UIButton)
    {
        if (numberLabel.text! == "0")
        {
            numberLabel.text = "0"
        } else
        {
            previusNumber = Double(numberLabel.text!)!
            numberLabel.text = "%"
            whatToDo = "%"
            zero.isEnabled = true
            one.isEnabled = true
            two.isEnabled = true
            three.isEnabled = true
            four.isEnabled = true
            five.isEnabled = true
            six.isEnabled = true
            seven.isEnabled = true
            eight.isEnabled = true
            nine.isEnabled = true
            comma.isEnabled = true
        }
        
    }
    
    @IBAction func equal(_ sender: UIButton)
    {
        
        let secondNumber = Double(numberLabel.text!)!
        zero.isEnabled = false
        one.isEnabled = false
        two.isEnabled = false
        three.isEnabled = false
        four.isEnabled = false
        five.isEnabled = false
        six.isEnabled = false
        seven.isEnabled = false
        eight.isEnabled = false
        nine.isEnabled = false
        comma.isEnabled = false
        
        if (whatToDo == "+")
        {
            numberLabel.text = String(previusNumber + secondNumber)
            var textLabel3 = numberLabel.text!
            if (textLabel3[textLabel3.index(before: textLabel3.endIndex)] == "0")
            {
                textLabel3.remove(at: textLabel3.index(before: textLabel3.endIndex))
                numberLabel.text = textLabel3
                if (textLabel3[textLabel3.index(before: textLabel3.endIndex)] == ".")
                {
                    textLabel3.remove(at: textLabel3.index(before: textLabel3.endIndex))
                    numberLabel.text = textLabel3
                }
            }
        } else if (whatToDo == "-")
        {
            numberLabel.text = String(previusNumber - secondNumber)
            var textLabel3 = numberLabel.text!
            if (textLabel3[textLabel3.index(before: textLabel3.endIndex)] == "0")
            {
                textLabel3.remove(at: textLabel3.index(before: textLabel3.endIndex))
                numberLabel.text = textLabel3
                if (textLabel3[textLabel3.index(before: textLabel3.endIndex)] == ".")
                {
                    textLabel3.remove(at: textLabel3.index(before: textLabel3.endIndex))
                    numberLabel.text = textLabel3
                }
            }

        } else if (whatToDo == "×")
        {
            numberLabel.text = String(previusNumber * secondNumber)
            var textLabel3 = numberLabel.text!
            if (textLabel3[textLabel3.index(before: textLabel3.endIndex)] == "0")
            {
                textLabel3.remove(at: textLabel3.index(before: textLabel3.endIndex))
                numberLabel.text = textLabel3
                if (textLabel3[textLabel3.index(before: textLabel3.endIndex)] == ".")
                {
                    textLabel3.remove(at: textLabel3.index(before: textLabel3.endIndex))
                    numberLabel.text = textLabel3
                }
            }

        } else if (whatToDo == "÷")
        {
            numberLabel.text = String(previusNumber / secondNumber)
            var textLabel3 = numberLabel.text!
            if (textLabel3[textLabel3.index(before: textLabel3.endIndex)] == "0")
            {
                textLabel3.remove(at: textLabel3.index(before: textLabel3.endIndex))
                numberLabel.text = textLabel3
                if (textLabel3[textLabel3.index(before: textLabel3.endIndex)] == ".")
                {
                    textLabel3.remove(at: textLabel3.index(before: textLabel3.endIndex))
                    numberLabel.text = textLabel3
                }
            }

        } else if (whatToDo == "%")
        {
            numberLabel.text = String((previusNumber * secondNumber) / 100)
            
            var textLabel3 = numberLabel.text!
            if (textLabel3[textLabel3.index(before: textLabel3.endIndex)] == "0")
            {
                textLabel3.remove(at: textLabel3.index(before: textLabel3.endIndex))
                numberLabel.text = textLabel3
                if (textLabel3[textLabel3.index(before: textLabel3.endIndex)] == ".")
                {
                    textLabel3.remove(at: textLabel3.index(before: textLabel3.endIndex))
                    numberLabel.text = textLabel3
                }
            }

        }
    }
    
    
    
    
    
    @IBAction func zero(_ sender: UIButton)
    {
        if (numberLabel.text! == "0"
            || numberLabel.text! == "+"
            || numberLabel.text! == "-"
            || numberLabel.text! == "×"
            || numberLabel.text! == "÷"
            || numberLabel.text! == "%")
        {
            numberLabel.text = String(sender.tag)
        } else
        {
            numberLabel.text = numberLabel.text! + String(sender.tag)
        }
    }
    
    @IBAction func one(_ sender: UIButton)
    {
        if (numberLabel.text! == "0"
            || numberLabel.text! == "+"
            || numberLabel.text! == "-"
            || numberLabel.text! == "×"
            || numberLabel.text! == "÷"
            || numberLabel.text! == "%")
        {
            numberLabel.text = String(sender.tag + 1)
        } else
        {
            numberLabel.text = numberLabel.text! + String(sender.tag + 1)
        }
    }
    
    @IBAction func two(_ sender: UIButton)
    {
        if (numberLabel.text! == "0"
            || numberLabel.text! == "+"
            || numberLabel.text! == "-"
            || numberLabel.text! == "×"
            || numberLabel.text! == "÷"
            || numberLabel.text! == "%")
        {
            numberLabel.text = String(sender.tag + 2)
        } else
        {
            numberLabel.text = numberLabel.text! + String(sender.tag + 2)
        }
    }
    
    @IBAction func three(_ sender: UIButton)
    {
        if (numberLabel.text! == "0"
            || numberLabel.text! == "+"
            || numberLabel.text! == "-"
            || numberLabel.text! == "×"
            || numberLabel.text! == "÷"
            || numberLabel.text! == "%")
        {
            numberLabel.text = String(sender.tag + 3)
        } else
        {
            numberLabel.text = numberLabel.text! + String(sender.tag + 3)
        }
    }
    
    @IBAction func four(_ sender: UIButton)
    {
        if (numberLabel.text! == "0"
            || numberLabel.text! == "+"
            || numberLabel.text! == "-"
            || numberLabel.text! == "×"
            || numberLabel.text! == "÷"
            || numberLabel.text! == "%")
        {
            numberLabel.text = String(sender.tag + 4)
        } else
        {
            numberLabel.text = numberLabel.text! + String(sender.tag + 4)
        }
    }
    
    @IBAction func five(_ sender: UIButton)
    {
        if (numberLabel.text! == "0"
            || numberLabel.text! == "+"
            || numberLabel.text! == "-"
            || numberLabel.text! == "×"
            || numberLabel.text! == "÷"
            || numberLabel.text! == "%")
        {
            numberLabel.text = String(sender.tag + 5)
        } else
        {
            numberLabel.text = numberLabel.text! + String(sender.tag + 5)
        }
    }
    
    @IBAction func six(_ sender: UIButton)
    {
        if (numberLabel.text! == "0"
            || numberLabel.text! == "+"
            || numberLabel.text! == "-"
            || numberLabel.text! == "×"
            || numberLabel.text! == "÷"
            || numberLabel.text! == "%")
        {
            numberLabel.text = String(sender.tag + 6)
        } else
        {
            numberLabel.text = numberLabel.text! + String(sender.tag + 6)
        }
    }
    
    @IBAction func seven(_ sender: UIButton)
    {
        if (numberLabel.text! == "0"
            || numberLabel.text! == "+"
            || numberLabel.text! == "-"
            || numberLabel.text! == "×"
            || numberLabel.text! == "÷"
            || numberLabel.text! == "%")
        {
            numberLabel.text = String(sender.tag + 7)
        } else
        {
            numberLabel.text = numberLabel.text! + String(sender.tag + 7)
        }
    }
    
    @IBAction func eight(_ sender: UIButton)
    {
        if (numberLabel.text! == "0"
            || numberLabel.text! == "+"
            || numberLabel.text! == "-"
            || numberLabel.text! == "×"
            || numberLabel.text! == "÷"
            || numberLabel.text! == "%")
        {
            numberLabel.text = String(sender.tag + 8)
        } else
        {
            numberLabel.text = numberLabel.text! + String(sender.tag + 8)
        }
    }
    
    @IBAction func nine(_ sender: UIButton)
    {
        if (numberLabel.text! == "0"
            || numberLabel.text! == "+"
            || numberLabel.text! == "-"
            || numberLabel.text! == "×"
            || numberLabel.text! == "÷"
            || numberLabel.text! == "%")
        {
            numberLabel.text = String(sender.tag + 9)
        } else
        {
            numberLabel.text = numberLabel.text! + String(sender.tag + 9)
        }
    }
}

